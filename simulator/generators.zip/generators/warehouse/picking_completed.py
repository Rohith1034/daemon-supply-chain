from datetime import datetime, timezone
import random

from core.db import Database
from core.ids import next_task_id
from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "PickingTaskCreated"



def generate_picking_task_created(allocation_id):


    with Database() as db:


        # -------------------------------------------------
        # Get exact allocation
        # -------------------------------------------------

        allocation = db.fetch_one(

            """

            SELECT

                allocation_id,
                order_id,
                product_id,
                warehouse_id,
                allocated_quantity,
                correlation_id


            FROM inventory_allocations


            WHERE allocation_id=%s


            AND allocation_status='RESERVED'


            FOR UPDATE


            """,

            (
                allocation_id,
            )

        )


        if not allocation:


            raise Exception(

                f"""
                Reserved allocation not found

                Allocation:
                {allocation_id}

                """

            )



        order_id = allocation["order_id"]

        product_id = allocation["product_id"]

        warehouse_id = allocation["warehouse_id"]

        quantity = allocation["allocated_quantity"]



        correlation_id = str(
            allocation["correlation_id"]
        )



        # -------------------------------------------------
        # Prevent duplicate picking task
        # -------------------------------------------------

        existing = db.fetch_one(

            """

            SELECT

                task_id


            FROM warehouse_tasks


            WHERE task_type='PICKING'


            AND allocation_id=%s


            LIMIT 1


            """,

            (
                allocation_id,
            )

        )


        if existing:


            raise Exception(

                f"""
                Picking task already exists

                TASK:
                {existing['task_id']}

                """

            )



        # -------------------------------------------------
        # Find inventory
        # -------------------------------------------------

        inventory = db.fetch_one(

            """

            SELECT

                inventory_id,
                location_id,
                reserved_quantity


            FROM inventory


            WHERE product_id=%s


            AND warehouse_id=%s


            FOR UPDATE


            """,

            (

                product_id,

                warehouse_id

            )

        )



        if not inventory:


            raise Exception(

                "Inventory missing"

            )



        if inventory["reserved_quantity"] < quantity:


            raise Exception(

                f"""

                Reservation mismatch


                Product:
                {product_id}


                Reserved:
                {inventory['reserved_quantity']}


                Required:
                {quantity}


                """

            )



        if not inventory["location_id"]:


            raise Exception(

                "Inventory location missing"

            )



        # -------------------------------------------------
        # Assign worker
        # -------------------------------------------------

        worker = db.fetch_one(

            """

            SELECT

                worker_id


            FROM workers


            WHERE warehouse_id=%s


            AND current_status='AVAILABLE'


            ORDER BY random()


            LIMIT 1


            FOR UPDATE


            """,

            (

                warehouse_id,

            )

        )


        if not worker:


            raise Exception(

                "No available warehouse worker"

            )



        worker_id = worker["worker_id"]



        now = datetime.now(
            timezone.utc
        )


        task_id = next_task_id(db)



        # -------------------------------------------------
        # Create picking task
        # -------------------------------------------------

        db.execute(

            """

            INSERT INTO warehouse_tasks

            (

                task_id,

                task_type,

                warehouse_id,

                product_id,

                location,

                quantity,

                priority,

                status,

                assigned_worker_id,

                estimated_minutes,

                created_at,

                assigned_at,

                correlation_id,

                allocation_id


            )


            VALUES

            (

                %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s

            )

            """,

            (

                task_id,

                "PICKING",

                warehouse_id,

                product_id,

                inventory["location_id"],

                quantity,

                random.choice(
                    [
                        "HIGH",
                        "MEDIUM",
                        "LOW"
                    ]
                ),

                "CREATED",

                worker_id,

                random.randint(
                    5,
                    20
                ),

                now,

                now,

                correlation_id,

                allocation_id

            )

        )



        # -------------------------------------------------
        # Lock worker
        # -------------------------------------------------

        db.execute(

            """

            UPDATE workers

            SET current_status='BUSY'

            WHERE worker_id=%s


            """,

            (

                worker_id,

            )

        )



        # -------------------------------------------------
        # Event
        # -------------------------------------------------

        payload = {


            "eventType":

                EVENT_NAME,


            "occurredAt":

                now.isoformat(),


            "pickingTask":

            {


                "taskId":

                    task_id,


                "allocationId":

                    allocation_id,


                "orderId":

                    order_id,


                "productId":

                    product_id,


                "warehouseId":

                    warehouse_id,


                "locationId":

                    inventory["location_id"],


                "quantity":

                    quantity,


                "workerId":

                    worker_id,


                "status":

                    "CREATED"


            },


            "correlationId":

                correlation_id


        }



        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="WAREHOUSE_TASK",

            aggregate_id=task_id,

            correlation_id=correlation_id,

            payload=payload

        )



        log_event_success(

            EVENT_NAME,

            {

                "task_id":task_id,

                "order_id":order_id,

                "product_id":product_id,

                "quantity":quantity,

                "worker_id":worker_id,

                "correlation_id":correlation_id

            }

        )


        return {

            "task_id":task_id

        }



if __name__=="__main__":

    try:

        generate_picking_task_created()


    except Exception as e:

        log_event_failure(
            EVENT_NAME,
            e
        )

        raise