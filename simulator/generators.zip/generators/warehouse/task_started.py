from datetime import datetime, timezone

from core.db import Database
from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "TaskStarted"



def generate_task_started():


    with Database() as db:


        # ------------------------------------
        # Find CREATED warehouse task
        # Supports:
        # PICKING
        # PACKING
        # PUTAWAY
        # RECEIVING
        # CYCLE_COUNT
        # ------------------------------------

        task = db.fetch_one(

            """
            SELECT *
            FROM warehouse_tasks
            WHERE status='CREATED'
            ORDER BY created_at
            LIMIT 1
            """

        )


        if not task:

            raise Exception(
                "No CREATED warehouse task found"
            )


        task_id = task["task_id"]


        now = datetime.now(
            timezone.utc
        )


        worker_id = task["assigned_worker_id"]



        # ------------------------------------
        # Update task status
        # ------------------------------------

        db.execute(

            """
            UPDATE warehouse_tasks

            SET

                status='STARTED',

                task_started_at=%s,

                started_by=%s,

                assigned_at=COALESCE(assigned_at,%s)

            WHERE task_id=%s

            """,

            (

                now,

                worker_id,

                now,

                task_id

            )

        )



        # ------------------------------------
        # Update worker status
        # ------------------------------------

        if worker_id:

            db.execute(

                """
                UPDATE workers

                SET current_status='BUSY'

                WHERE worker_id=%s

                """,

                (

                    worker_id,

                )

            )



        # ------------------------------------
        # Payload
        # ------------------------------------

        payload = {


            "eventType":

                EVENT_NAME,


            "occurredAt":

                now.isoformat(),


            "warehouseTask":

            {


                "taskId":

                    task_id,


                "taskType":

                    task["task_type"],


                "warehouseId":

                    task["warehouse_id"],


                "productId":

                    task["product_id"],


                "locationId":

                    task["location"],


                "shipmentId":

                    task["shipment_id"],


                "quantity":

                    task["quantity"],


                "workerId":

                    worker_id,


                "status":

                    "STARTED",


                "startedAt":

                    now.isoformat()

            },


            "correlationId":

                str(
                    task["correlation_id"]
                )

        }



        # ------------------------------------
        # Publish event
        # ------------------------------------

        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="WAREHOUSE_TASK",

            aggregate_id=task_id,

            correlation_id=str(
                task["correlation_id"]
            ),

            payload=payload

        )



        # ------------------------------------
        # Console Output
        # ------------------------------------

        log_event_success(

            EVENT_NAME,

            {

                "task_id":

                    task_id,


                "task_type":

                    task["task_type"],


                "warehouse_id":

                    task["warehouse_id"],


                "worker_id":

                    worker_id,


                "status":

                    "STARTED",


                "correlation_id":

                    task["correlation_id"]

            }

        )





if __name__ == "__main__":


    try:

        generate_task_started()


    except Exception as e:


        log_event_failure(

            EVENT_NAME,

            e

        )

        raise