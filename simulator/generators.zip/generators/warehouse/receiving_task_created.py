from datetime import datetime, timezone
import uuid


from core.db import Database

from core.ids import (
    next_task_id
)

from core.selectors import (
    get_available_worker
)

from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "ReceivingTaskCreated"



def generate_receiving_task_created():


    with Database() as db:


        # ----------------------------------------
        # Find arrived shipment
        # ----------------------------------------

        shipment = db.fetch_one(
            """
            SELECT *
            FROM shipments
            WHERE shipment_status='ARRIVED'
            ORDER BY shipment_date
            LIMIT 1
            """
        )


        if not shipment:

            raise Exception(
                "No ARRIVED shipment found"
            )


        shipment_id = shipment["shipment_id"]



        # ----------------------------------------
        # Check duplicate receiving task
        # ----------------------------------------

        existing = db.fetch_one(
            """
            SELECT task_id
            FROM warehouse_tasks
            WHERE shipment_id=%s
            AND task_type='RECEIVING'
            """,
            (
                shipment_id,
            )
        )


        if existing:

            raise Exception(
                f"Receiving task already exists {existing['task_id']}"
            )



        # ----------------------------------------
        # Generate task id
        # ----------------------------------------

        task_id = next_task_id(db)



        # ----------------------------------------
        # Get worker
        # ----------------------------------------

        worker = get_available_worker(
            db,
            shipment["warehouse_id"]
        )


        if not worker:

            raise Exception(
                "No available warehouse worker"
            )



        # ----------------------------------------
        # Shipment quantity
        # ----------------------------------------

        quantity_result = db.fetch_one(

            """
            SELECT
                SUM(shipped_quantity) AS total_quantity
            FROM shipment_items
            WHERE shipment_id=%s
            """,

            (
                shipment_id,
            )
        )


        quantity = (
            quantity_result["total_quantity"]
            if quantity_result["total_quantity"]
            else 0
        )



        # ----------------------------------------
        # Correlation ID
        # ----------------------------------------

        correlation_id = str(
            shipment["correlation_id"]
            or "00000000-0000-0000-0000-000000000000"
        ) if shipment.get("correlation_id") else str(uuid.uuid4())



        now = datetime.now(
            timezone.utc
        )



        # ----------------------------------------
        # Create warehouse receiving task
        # ----------------------------------------

        db.execute(

            """
            INSERT INTO warehouse_tasks
            (
                task_id,
                task_type,
                warehouse_id,
                shipment_id,
                quantity,
                priority,
                status,
                assigned_worker_id,
                created_by,
                assigned_at,
                correlation_id,
                expected_quantity
            )

            VALUES
            (
                %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s
            )

            """,

            (

                task_id,

                "RECEIVING",

                shipment["warehouse_id"],

                shipment_id,

                quantity,

                "HIGH",

                "CREATED",

                worker["worker_id"],

                "WMS",

                now,

                correlation_id,

                quantity

            )

        )



        # ----------------------------------------
        # Event Payload
        # ----------------------------------------

        payload = {


            "eventType":

                EVENT_NAME,


            "occurredAt":

                now.isoformat(),


            "warehouseTask":

            {

                "taskId":

                    task_id,


                "taskType":

                    "RECEIVING",


                "shipmentId":

                    shipment_id,


                "warehouseId":

                    shipment["warehouse_id"],


                "workerId":

                    worker["worker_id"],


                "quantity":

                    quantity,


                "priority":

                    "HIGH",


                "status":

                    "CREATED"

            },


            "correlationId":

                correlation_id

        }



        # ----------------------------------------
        # Outbox
        # ----------------------------------------

        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="WAREHOUSE_TASK",

            aggregate_id=task_id,

            correlation_id=correlation_id,

            payload=payload

        )



        # ----------------------------------------
        # Output
        # ----------------------------------------

        log_event_success(

            EVENT_NAME,

            {

                "task_id":

                    task_id,


                "shipment_id":

                    shipment_id,


                "warehouse_id":

                    shipment["warehouse_id"],


                "worker_id":

                    worker["worker_id"],


                "quantity":

                    quantity,


                "correlation_id":

                    correlation_id

            }

        )




if __name__ == "__main__":


    try:

        generate_receiving_task_created()


    except Exception as e:


        log_event_failure(

            EVENT_NAME,

            e

        )

        raise