from datetime import datetime, timezone
import uuid


from core.db import Database

from core.ids import next_task_id

from core.selectors import get_available_worker

from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "PickingTaskCreated"



def generate_picking_task_created():


    with Database() as db:


        # ----------------------------------------
        # Find reserved inventory allocation
        # ----------------------------------------

        allocation = db.fetch_one(

            """

            SELECT

                allocation_id,
                order_id,
                warehouse_id,
                product_id,
                allocated_quantity,
                correlation_id

            FROM inventory_allocations

            WHERE allocation_status='RESERVED'

            ORDER BY allocated_at

            LIMIT 1

            """

        )


        if not allocation:

            raise Exception(
                "No RESERVED inventory allocation found"
            )

        # ----------------------------------------
        # Check duplicate picking task
        # ----------------------------------------

        existing = db.fetch_one(

            """

            SELECT task_id

            FROM warehouse_tasks

            WHERE product_id=%s

            AND warehouse_id=%s

            AND task_type='PICKING'

            AND status IN ('CREATED','STARTED')

            LIMIT 1

            """,

            (

                allocation["product_id"],

                allocation["warehouse_id"]

            )

        )

        if existing:
            raise Exception(
                f"Picking task already exists {existing['task_id']}"
            )


        # ----------------------------------------
        # Find inventory location
        # ----------------------------------------

        inventory = db.fetch_one(

            """

            SELECT

                inventory_id,

                location_id

            FROM inventory

            WHERE product_id=%s

            AND warehouse_id=%s

            """

            ,

            (

                allocation["product_id"],

                allocation["warehouse_id"]

            )

        )



        if not inventory:

            raise Exception(
                "Inventory record not found"
            )



        if not inventory["location_id"]:

            raise Exception(
                "Inventory has no location assigned"
            )



        # ----------------------------------------
        # Generate task id
        # ----------------------------------------

        task_id = next_task_id(db)



        # ----------------------------------------
        # Assign picker
        # ----------------------------------------

        worker = get_available_worker(

            db,

            allocation["warehouse_id"]

        )


        if not worker:

            raise Exception(
                "No available picker found"
            )



        # ----------------------------------------
        # Correlation ID
        # ----------------------------------------

        correlation_id = (

            str(allocation["correlation_id"])

            if allocation["correlation_id"]

            else str(uuid.uuid4())

        )



        now = datetime.now(
            timezone.utc
        )



        quantity = allocation["allocated_quantity"]



        # ----------------------------------------
        # Create picking task
        # ----------------------------------------

        db.execute(

            """

            INSERT INTO warehouse_tasks

            (

                task_id,

                task_type,

                warehouse_id,

                product_id,

                location,

                quantity,

                priority,

                status,

                assigned_worker_id,

                created_by,

                assigned_at,

                correlation_id

            )

            VALUES

            (

                %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s

            )

            """

            ,

            (

                task_id,

                "PICKING",

                allocation["warehouse_id"],

                allocation["product_id"],

                inventory["location_id"],

                quantity,

                "HIGH",

                "CREATED",

                worker["worker_id"],

                "WMS",

                now,

                correlation_id

            )

        )



        # ----------------------------------------
        # Payload
        # ----------------------------------------

        payload = {


            "eventType":

                EVENT_NAME,


            "occurredAt":

                now.isoformat(),


            "pickingTask":

            {


                "taskId":

                    task_id,


                "taskType":

                    "PICKING",


                "orderId":

                    allocation["order_id"],


                "warehouseId":

                    allocation["warehouse_id"],


                "productId":

                    allocation["product_id"],


                "locationId":

                    inventory["location_id"],


                "quantity":

                    quantity,


                "workerId":

                    worker["worker_id"],


                "status":

                    "CREATED"

            },


            "correlationId":

                correlation_id

        }



        # ----------------------------------------
        # Outbox
        # ----------------------------------------

        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="WAREHOUSE_TASK",

            aggregate_id=task_id,

            correlation_id=correlation_id,

            payload=payload

        )



        # ----------------------------------------
        # Output
        # ----------------------------------------

        log_event_success(

            EVENT_NAME,

            {


                "task_id":

                    task_id,


                "order_id":

                    allocation["order_id"],


                "warehouse_id":

                    allocation["warehouse_id"],


                "product_id":

                    allocation["product_id"],


                "location_id":

                    inventory["location_id"],


                "quantity":

                    quantity,


                "worker_id":

                    worker["worker_id"],


                "correlation_id":

                    correlation_id

            }

        )




if __name__ == "__main__":


    try:

        generate_picking_task_created()


    except Exception as e:


        log_event_failure(

            EVENT_NAME,

            e

        )

        raise