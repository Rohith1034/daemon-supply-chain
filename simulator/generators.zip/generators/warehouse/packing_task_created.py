from datetime import datetime, timezone
import uuid

from core.db import Database

from core.ids import next_task_id

from core.selectors import get_available_worker

from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "PackingTaskCreated"



def generate_packing_task_created():

    with Database() as db:


        # ------------------------------------
        # Find picked task
        # ------------------------------------

        picking_task = db.fetch_one(
            """
            SELECT
                *
            FROM warehouse_tasks
            WHERE task_type='PICKING'
            AND status='COMPLETED'
            ORDER BY task_completed_at
            LIMIT 1
            """
        )


        if not picking_task:

            raise Exception(
                "No completed picking task found"
            )


        task_id = picking_task["task_id"]



        # ------------------------------------
        # Check duplicate packing task
        # ------------------------------------

        existing = db.fetch_one(
            """
            SELECT task_id
            FROM warehouse_tasks
            WHERE task_type='PACKING'
            AND product_id=%s
            AND shipment_id=%s
            """,
            (
                picking_task["product_id"],
                picking_task["shipment_id"]
            )
        )


        if existing:

            raise Exception(
                f"Packing task already exists {existing['task_id']}"
            )



        # ------------------------------------
        # Generate task id
        # ------------------------------------

        packing_task_id = next_task_id(db)



        # ------------------------------------
        # Assign worker
        # ------------------------------------

        worker = get_available_worker(
            db,
            picking_task["warehouse_id"]
        )


        if not worker:

            raise Exception(
                "No available packing worker"
            )



        now = datetime.now(
            timezone.utc
        )



        correlation_id = str(
            picking_task["correlation_id"]
        ) if picking_task["correlation_id"] else str(uuid.uuid4())



        # ------------------------------------
        # Create packing task
        # ------------------------------------

        db.execute(

            """
            INSERT INTO warehouse_tasks
            (
                task_id,
                task_type,
                warehouse_id,
                shipment_id,
                product_id,
                location,
                quantity,
                priority,
                status,
                assigned_worker_id,
                created_by,
                assigned_at,
                correlation_id,
                expected_quantity
            )

            VALUES
            (
                %s,%s,%s,%s,%s,%s,
                %s,%s,%s,%s,%s,%s,%s,%s
            )

            """,

            (

                packing_task_id,

                "PACKING",

                picking_task["warehouse_id"],

                picking_task["shipment_id"],

                picking_task["product_id"],

                picking_task["location"],

                picking_task["quantity"],

                "HIGH",

                "CREATED",

                worker["worker_id"],

                "WMS",

                now,

                correlation_id,

                picking_task["quantity"]

            )

        )



        # ------------------------------------
        # Payload
        # ------------------------------------

        payload = {


            "eventType":
                EVENT_NAME,


            "occurredAt":
                now.isoformat(),


            "packingTask":
            {

                "taskId":
                    packing_task_id,


                "taskType":
                    "PACKING",


                "orderId":
                    picking_task.get("order_id"),


                "warehouseId":
                    picking_task["warehouse_id"],


                "productId":
                    picking_task["product_id"],


                "quantity":
                    picking_task["quantity"],


                "workerId":
                    worker["worker_id"],


                "status":
                    "CREATED"

            },


            "correlationId":
                correlation_id

        }



        # ------------------------------------
        # Outbox
        # ------------------------------------

        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="WAREHOUSE_TASK",

            aggregate_id=packing_task_id,

            correlation_id=correlation_id,

            payload=payload

        )



        log_event_success(

            EVENT_NAME,

            {

                "task_id":
                    packing_task_id,

                "warehouse_id":
                    picking_task["warehouse_id"],

                "product_id":
                    picking_task["product_id"],

                "worker_id":
                    worker["worker_id"],

                "correlation_id":
                    correlation_id

            }

        )



if __name__ == "__main__":


    try:

        generate_packing_task_created()


    except Exception as e:


        log_event_failure(
            EVENT_NAME,
            e
        )

        raise