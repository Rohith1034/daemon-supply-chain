from datetime import datetime, timezone
import uuid

from core.db import Database
from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "InventoryReserved"



def generate_inventory_reserved():

    with Database() as db:


        # --------------------------------------------------
        # Get oldest allocated inventory allocation
        # --------------------------------------------------

        allocation = db.fetch_one(
            """

            SELECT

                allocation_id,
                order_id,
                warehouse_id,
                product_id,
                allocated_quantity,
                correlation_id


            FROM inventory_allocations


            WHERE allocation_status='ALLOCATED'


            ORDER BY allocated_at


            LIMIT 1


            """
        )


        if not allocation:

            raise Exception(
                "No ALLOCATED inventory found"
            )



        allocation_id = allocation["allocation_id"]

        order_id = allocation["order_id"]

        warehouse_id = allocation["warehouse_id"]

        product_id = allocation["product_id"]

        quantity = allocation["allocated_quantity"]



        correlation_id = (
            str(allocation["correlation_id"])
            if allocation["correlation_id"]
            else str(uuid.uuid4())
        )



        now = datetime.now(
            timezone.utc
        )



        # --------------------------------------------------
        # Find inventory
        # --------------------------------------------------

        inventory = db.fetch_one(
            """

            SELECT

                inventory_id,
                on_hand_quantity,
                reserved_quantity


            FROM inventory


            WHERE product_id=%s

            AND warehouse_id=%s


            LIMIT 1


            """,

            (

                product_id,

                warehouse_id

            )

        )



        if not inventory:

            raise Exception(
                f"Inventory missing {product_id}"
            )



        available = (
            inventory["on_hand_quantity"]
            -
            inventory["reserved_quantity"]
        )



        if available < quantity:

            raise Exception(
                f"""
                Insufficient available inventory

                PRODUCT:
                {product_id}

                AVAILABLE:
                {available}

                REQUIRED:
                {quantity}

                """
            )



        # --------------------------------------------------
        # Reserve inventory
        # --------------------------------------------------

        db.execute(
            """

            UPDATE inventory


            SET

                reserved_quantity =
                    reserved_quantity + %s,


                last_updated_at=%s


            WHERE inventory_id=%s


            """,

            (

                quantity,

                now,

                inventory["inventory_id"]

            )

        )



        # --------------------------------------------------
        # Update allocation status
        # --------------------------------------------------

        db.execute(
            """

            UPDATE inventory_allocations


            SET

                allocation_status='RESERVED',

                correlation_id=%s


            WHERE allocation_id=%s


            """,

            (

                correlation_id,

                allocation_id

            )

        )



        # --------------------------------------------------
        # Inventory ledger
        # --------------------------------------------------

        db.execute(
            """

            INSERT INTO inventory_transactions

            (

                inventory_id,

                product_id,

                warehouse_id,

                transaction_type,

                quantity,

                reference_type,

                reference_id,

                correlation_id

            )


            VALUES

            (%s,%s,%s,%s,%s,%s,%s,%s)


            """,

            (

                inventory["inventory_id"],

                product_id,

                warehouse_id,

                "RESERVATION",

                quantity,

                "ORDER",

                order_id,

                correlation_id

            )

        )



        # --------------------------------------------------
        # Event
        # --------------------------------------------------

        payload = {


            "eventType":
                EVENT_NAME,


            "occurredAt":
                now.isoformat(),


            "reservation":

            {

                "allocationId":
                    allocation_id,


                "orderId":
                    order_id,


                "productId":
                    product_id,


                "warehouseId":
                    warehouse_id,


                "quantity":
                    quantity,


                "status":
                    "RESERVED"

            },


            "correlationId":
                correlation_id

        }



        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="ORDER",

            aggregate_id=order_id,

            correlation_id=correlation_id,

            payload=payload

        )



        log_event_success(

            EVENT_NAME,

            {

                "order_id":
                    order_id,

                "product_id":
                    product_id,

                "warehouse_id":
                    warehouse_id,

                "quantity":
                    quantity,

                "correlation_id":
                    correlation_id

            }

        )





if __name__ == "__main__":

    try:

        generate_inventory_reserved()


    except Exception as e:

        log_event_failure(
            EVENT_NAME,
            e
        )

        raise