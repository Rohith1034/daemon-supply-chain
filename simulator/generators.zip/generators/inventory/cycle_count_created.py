from datetime import datetime, timezone
import uuid
import random


from core.db import Database

from core.ids import next_task_id

from core.selectors import get_available_worker

from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "CycleCountCreated"



def generate_cycle_count_created():


    with Database() as db:


        # ---------------------------------------
        # Find inventory available for counting
        # ---------------------------------------

        inventory = db.fetch_one(

            """
            SELECT

                i.product_id,
                i.warehouse_id,
                i.location_id,
                i.on_hand_quantity


            FROM inventory i


            WHERE

                i.location_id IS NOT NULL


            ORDER BY random()

            LIMIT 1

            """

        )


        if not inventory:

            raise Exception(
                "No inventory available for cycle count"
            )



        # ---------------------------------------
        # Check existing cycle count task
        # ---------------------------------------

        existing = db.fetch_one(

            """

            SELECT task_id

            FROM warehouse_tasks

            WHERE

                task_type='CYCLE_COUNT'

            AND

                product_id=%s

            AND

                location=%s

            AND

                status IN ('CREATED','STARTED')


            """,

            (

                inventory["product_id"],

                inventory["location_id"]

            )

        )


        if existing:

            raise Exception(

                f"Cycle count already exists {existing['task_id']}"

            )



        # ---------------------------------------
        # Get worker
        # ---------------------------------------

        worker = get_available_worker(

            db,

            inventory["warehouse_id"]

        )


        if not worker:

            raise Exception(
                "No available worker for cycle count"
            )



        # ---------------------------------------
        # Generate task id
        # ---------------------------------------

        task_id = next_task_id(db)



        now = datetime.now(
            timezone.utc
        )



        # ---------------------------------------
        # Correlation ID
        # ---------------------------------------

        correlation_id = str(
            uuid.uuid4()
        )



        # ---------------------------------------
        # Estimate duration
        # ---------------------------------------

        estimated_minutes = random.randint(
            10,
            30
        )



        # ---------------------------------------
        # Create cycle count task
        # ---------------------------------------

        db.execute(

            """

            INSERT INTO warehouse_tasks

            (

                task_id,

                task_type,

                warehouse_id,

                product_id,

                location,

                quantity,

                expected_quantity,

                priority,

                status,

                assigned_worker_id,

                estimated_minutes,

                created_at,

                created_by,

                assigned_at,

                correlation_id,
                
                allocation_id
            )


            VALUES

            (

                %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s

            )

            """,

            (

                task_id,

                "CYCLE_COUNT",

                inventory["warehouse_id"],

                inventory["product_id"],

                inventory["location_id"],

                inventory["on_hand_quantity"],

                inventory["on_hand_quantity"],

                "MEDIUM",

                "CREATED",

                worker["worker_id"],

                estimated_minutes,

                now,

                "WAREHOUSE_SYSTEM",

                now,

                allocation_id,

                correlation_id

            )

        )



        # ---------------------------------------
        # Event Payload
        # ---------------------------------------

        payload = {


            "eventType":

                EVENT_NAME,


            "occurredAt":

                now.isoformat(),


            "cycleCountTask":

            {

                "taskId":

                    task_id,


                "warehouseId":

                    inventory["warehouse_id"],


                "locationId":

                    inventory["location_id"],


                "productId":

                    inventory["product_id"],


                "expectedQuantity":

                    inventory["on_hand_quantity"],


                "workerId":

                    worker["worker_id"],


                "status":

                    "CREATED"


            },


            "correlationId":

                correlation_id

        }



        # ---------------------------------------
        # Publish Event
        # ---------------------------------------

        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="WAREHOUSE_TASK",

            aggregate_id=task_id,

            correlation_id=correlation_id,

            payload=payload

        )



        # ---------------------------------------
        # Log
        # ---------------------------------------

        log_event_success(

            EVENT_NAME,

            {


                "task_id":

                    task_id,


                "warehouse_id":

                    inventory["warehouse_id"],


                "location_id":

                    inventory["location_id"],


                "product_id":

                    inventory["product_id"],


                "expected_quantity":

                    inventory["on_hand_quantity"],


                "worker_id":

                    worker["worker_id"],


                "correlation_id":

                    correlation_id

            }

        )




if __name__ == "__main__":


    try:

        generate_cycle_count_created()


    except Exception as e:


        log_event_failure(

            EVENT_NAME,

            e

        )

        raise