from datetime import datetime, timezone

from core.db import Database
from core.ids import next_allocation_id
from core.outbox import publish_event

from core.logger import (
    log_event_success,
    log_event_failure
)


EVENT_NAME = "InventoryAllocationCreated"



def generate_inventory_allocation_created():

    with Database() as db:


        # ---------------------------------------------
        # Find CREATED order which is NOT allocated
        # ---------------------------------------------

        order = db.fetch_one(
            """

            SELECT

                o.order_id,
                o.warehouse_id,
                o.correlation_id

            FROM orders o

            JOIN order_items oi

            ON oi.order_id=o.order_id


            LEFT JOIN inventory_allocations ia

            ON ia.order_id=o.order_id


            WHERE

                o.order_status='CREATED'

            AND

                ia.order_id IS NULL


            ORDER BY

                o.created_at ASC


            LIMIT 1


            """
        )


        if not order:

            raise Exception(
                "No order available for allocation"
            )



        order_id = order["order_id"]

        warehouse_id = order["warehouse_id"]

        correlation = str(
            order["correlation_id"]
        )



        # ---------------------------------------------
        # Get order items
        # ---------------------------------------------

        items = db.fetch_all(

            """

            SELECT

                product_id,
                quantity


            FROM order_items


            WHERE order_id=%s


            """,

            (
                order_id,
            )

        )


        if not items:

            raise Exception(
                "Order has no items"
            )



        allocations = []



        # ---------------------------------------------
        # Allocate Inventory
        # ---------------------------------------------

        for item in items:


            inventory = db.fetch_one(

                """

                SELECT


                    inventory_id,

                    available_quantity


                FROM inventory


                WHERE

                    product_id=%s


                AND

                    warehouse_id=%s


                FOR UPDATE


                """,

                (

                    item["product_id"],

                    warehouse_id

                )

            )



            if not inventory:

                raise Exception(

                    f"No inventory found {item['product_id']}"

                )



            available = inventory[
                "available_quantity"
            ]



            requested = item[
                "quantity"
            ]



            if available < requested:

                raise Exception(

                    f"""
                    Insufficient stock

                    Product:
                    {item['product_id']}

                    Required:
                    {requested}

                    Available:
                    {available}
                    """

                )



            allocation_id = next_allocation_id(db)



            # ---------------------------------
            # Insert allocation
            # ---------------------------------

            db.execute(

                """

                INSERT INTO inventory_allocations

                (

                    allocation_id,

                    order_id,

                    warehouse_id,

                    product_id,

                    allocated_quantity,

                    allocation_status,

                    correlation_id

                )


                VALUES

                (%s,%s,%s,%s,%s,%s,%s)


                """,

                (

                    allocation_id,

                    order_id,

                    warehouse_id,

                    item["product_id"],

                    requested,

                    "ALLOCATED",

                    correlation

                )

            )



            # ---------------------------------
            # Inventory Ledger
            # ---------------------------------

            db.execute(

                """

                INSERT INTO inventory_transactions

                (

                    inventory_id,

                    product_id,

                    warehouse_id,

                    transaction_type,

                    quantity,

                    reference_type,

                    reference_id,

                    correlation_id

                )


                VALUES

                (%s,%s,%s,%s,%s,%s,%s,%s)


                """,

                (

                    inventory["inventory_id"],

                    item["product_id"],

                    warehouse_id,

                    "ALLOCATION",

                    requested,

                    "ORDER",

                    order_id,

                    correlation

                )

            )



            allocations.append(

                {

                    "allocationId":
                        allocation_id,


                    "productId":
                        item["product_id"],


                    "quantity":
                        requested

                }

            )



        now = datetime.now(
            timezone.utc
        )



        # ---------------------------------------------
        # Update Order Status
        # ---------------------------------------------

        db.execute(

            """

            UPDATE orders

            SET

                order_status='ALLOCATED'


            WHERE order_id=%s


            """,

            (

                order_id,

            )

        )



        # ---------------------------------------------
        # Event Payload
        # ---------------------------------------------

        payload = {


            "eventType":
                EVENT_NAME,


            "occurredAt":
                now.isoformat(),


            "order":

            {

                "orderId":
                    order_id,


                "warehouseId":
                    warehouse_id,


                "allocations":
                    allocations

            },


            "correlationId":
                correlation

        }



        publish_event(

            db=db,

            event_type=EVENT_NAME,

            aggregate_type="ORDER",

            aggregate_id=order_id,

            correlation_id=correlation,

            payload=payload

        )



        log_event_success(

            EVENT_NAME,

            {

                "order_id":
                    order_id,


                "warehouse_id":
                    warehouse_id,


                "items":
                    len(allocations),


                "correlation_id":
                    correlation

            }

        )




if __name__ == "__main__":


    try:

        generate_inventory_allocation_created()


    except Exception as e:

        log_event_failure(

            EVENT_NAME,

            e

        )

        raise